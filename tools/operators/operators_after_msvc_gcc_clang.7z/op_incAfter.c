// -*- coding: utf-8; mode: c; -*-

#include <stdio.h>
#include <stdbool.h>



typedef struct {
    int x;
    int y;
} struct1_t;

typedef struct {
    int x;
    int y;
    int z;
} struct2_t;




int main(void)
{
    bool b_0 = true;
    bool b_1 = true;
// (MSVC)> warning C4189: 'b_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     bool b_2 = true;
    unsigned char uc_0 = 'B';
    unsigned char uc_1 = 'B';
// (MSVC)> warning C4189: 'uc_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     unsigned char uc_2 = 'B';
    signed char sc_0 = 'C';
    signed char sc_1 = 'C';
// (MSVC)> warning C4189: 'sc_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     signed char sc_2 = 'C';
    unsigned short int uSi_0 = 1;
    unsigned short int uSi_1 = 1;
// (MSVC)> warning C4189: 'uSi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     unsigned short int uSi_2 = 1;
    signed short int sSi_0 = 2;
    signed short int sSi_1 = 2;
// (MSVC)> warning C4189: 'sSi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     signed short int sSi_2 = 2;
    unsigned int ui_0 = 3;
    unsigned int ui_1 = 3;
// (MSVC)> warning C4189: 'ui_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     unsigned int ui_2 = 3;
    signed int si_0 = 4;
    signed int si_1 = 4;
// (MSVC)> warning C4189: 'si_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     signed int si_2 = 4;
    unsigned long int uLi_0 = 5;
    unsigned long int uLi_1 = 5;
// (MSVC)> warning C4189: 'uLi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     unsigned long int uLi_2 = 5;
    signed long int sLi_0 = 6;
    signed long int sLi_1 = 6;
// (MSVC)> warning C4189: 'sLi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     signed long int sLi_2 = 6;
    unsigned long long int uLLi_0 = 7;
    unsigned long long int uLLi_1 = 7;
// (MSVC)> warning C4189: 'uLLi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     unsigned long long int uLLi_2 = 7;
    signed long long int sLLi_0 = 8;
    signed long long int sLLi_1 = 8;
// (MSVC)> warning C4189: 'sLLi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     signed long long int sLLi_2 = 8;
    float f_0 = 0.1f;
    float f_1 = 0.1f;
// (MSVC)> warning C4189: 'f_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     float f_2 = 0.1f;
    double d_0 = 0.2;
    double d_1 = 0.2;
// (MSVC)> warning C4189: 'd_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double d_2 = 0.2;
    long double Ld_0 = 0.3;
    long double Ld_1 = 0.3;
// (MSVC)> warning C4189: 'Ld_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     long double Ld_2 = 0.3;
// (MSVC)> warning C4189: 'ai_0': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     int ai_0[] = {1, 2, 3};
// (MSVC)> warning C4189: 'ai_1': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     int ai_1[] = {1, 2, 3};
// (MSVC)> warning C4189: 'ai_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     int ai_2[] = {1, 2, 3};
// (MSVC)> warning C4189: 'ad_0': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double ad_0[] = {0.1, 0.2, 0.3};
// (MSVC)> warning C4189: 'ad_1': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double ad_1[] = {0.1, 0.2, 0.3};
// (MSVC)> warning C4189: 'ad_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double ad_2[] = {0.1, 0.2, 0.3};
// (MSVC)> warning C4189: 'struct$si$si_0': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct1_t struct$si$si_0 = {0, 0};
// (MSVC)> warning C4189: 'struct$si$si_1': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct1_t struct$si$si_1 = {0, 0};
// (MSVC)> warning C4189: 'struct$si$si_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct1_t struct$si$si_2 = {0, 0};
// (MSVC)> warning C4189: 'struct$si$si$si_0': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct2_t struct$si$si$si_0 = {0, 0, 0};
// (MSVC)> warning C4189: 'struct$si$si$si_1': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct2_t struct$si$si$si_1 = {0, 0, 0};
// (MSVC)> warning C4189: 'struct$si$si$si_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct2_t struct$si$si$si_2 = {0, 0, 0};
    char * pc_0 = NULL;
    char * pc_1 = NULL;
// (MSVC)> warning C4189: 'pc_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     char * pc_2 = NULL;
    short int * pSi_0 = NULL;
    short int * pSi_1 = NULL;
// (MSVC)> warning C4189: 'pSi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     short int * pSi_2 = NULL;
    int * pi_0 = NULL;
    int * pi_1 = NULL;
// (MSVC)> warning C4189: 'pi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     int * pi_2 = NULL;
    long int * pLi_0 = NULL;
    long int * pLi_1 = NULL;
// (MSVC)> warning C4189: 'pLi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     long int * pLi_2 = NULL;
    long long int * pLLi_0 = NULL;
    long long int * pLLi_1 = NULL;
// (MSVC)> warning C4189: 'pLLi_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     long long int * pLLi_2 = NULL;
    float * pf_0 = NULL;
    float * pf_1 = NULL;
// (MSVC)> warning C4189: 'pf_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     float * pf_2 = NULL;
    double * pd_0 = NULL;
    double * pd_1 = NULL;
// (MSVC)> warning C4189: 'pd_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double * pd_2 = NULL;
    long double * pLd_0 = NULL;
    long double * pLd_1 = NULL;
// (MSVC)> warning C4189: 'pLd_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     long double * pLd_2 = NULL;
// (MSVC)> warning C4189: 'pai_0': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     int (* pai_0)[] = NULL;
// (MSVC)> warning C4189: 'pai_1': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     int (* pai_1)[] = NULL;
// (MSVC)> error C2220: la siguiente advertencia se trata como un error
// (MSVC)> warning C4189: 'pai_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     int (* pai_2)[] = NULL;
// (MSVC)> warning C4189: 'pad_0': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double (* pad_0)[] = NULL;
// (MSVC)> warning C4189: 'pad_1': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double (* pad_1)[] = NULL;
// (MSVC)> warning C4189: 'pad_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     double (* pad_2)[] = NULL;
    struct1_t * pstruct$si$si_0 = NULL;
    struct1_t * pstruct$si$si_1 = NULL;
// (MSVC)> warning C4189: 'pstruct$si$si_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct1_t * pstruct$si$si_2 = NULL;
    struct2_t * pstruct$si$si$si_0 = NULL;
    struct2_t * pstruct$si$si$si_1 = NULL;
// (MSVC)> warning C4189: 'pstruct$si$si$si_2': la variable local se ha inicializado pero no se hace referencia a ella
// (MSVC)     struct2_t * pstruct$si$si$si_2 = NULL;


// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     b_0 = b_1 ++;
    b_0 = uc_1 ++;
    b_0 = sc_1 ++;
    b_0 = uSi_1 ++;
    b_0 = sSi_1 ++;
    b_0 = ui_1 ++;
    b_0 = si_1 ++;
    b_0 = uLi_1 ++;
    b_0 = sLi_1 ++;
    b_0 = uLLi_1 ++;
    b_0 = sLLi_1 ++;
    b_0 = f_1 ++;
    b_0 = d_1 ++;
    b_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)     b_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)     b_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     b_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     b_0 = struct$si$si$si_1 ++;
    b_0 = pc_1 ++;
    b_0 = pSi_1 ++;
    b_0 = pi_1 ++;
    b_0 = pLi_1 ++;
    b_0 = pLLi_1 ++;
    b_0 = pf_1 ++;
    b_0 = pd_1 ++;
    b_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)     b_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)     b_0 = pad_1 ++;
    b_0 = pstruct$si$si_1 ++;
    b_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     uc_0 = b_1 ++;
    uc_0 = uc_1 ++;
    uc_0 = sc_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned short' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = uSi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'short' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = sSi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned int' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = ui_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'int' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = si_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned long' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = uLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'unsigned char'; posible pérdida de datos
// (MSVC)     uc_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uc_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uc_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uc_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uc_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     uc_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     uc_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uc_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     uc_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     uc_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     uc_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uc_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     uc_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     uc_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     uc_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     uc_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned char' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     uc_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     sc_0 = b_1 ++;
    sc_0 = uc_1 ++;
    sc_0 = sc_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned short' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = uSi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'short' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = sSi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned int' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = ui_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'int' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = si_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned long' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = uLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'char'; posible pérdida de datos
// (MSVC)     sc_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sc_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sc_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sc_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sc_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     sc_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     sc_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sc_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     sc_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     sc_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     sc_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sc_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     sc_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     sc_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     sc_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     sc_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'char' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     sc_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     uSi_0 = b_1 ++;
    uSi_0 = uc_1 ++;
    uSi_0 = sc_1 ++;
    uSi_0 = uSi_1 ++;
    uSi_0 = sSi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned int' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = ui_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'int' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = si_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned long' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = uLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'unsigned short'; posible pérdida de datos
// (MSVC)     uSi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uSi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uSi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uSi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uSi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     uSi_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     uSi_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uSi_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     uSi_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     uSi_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     uSi_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uSi_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     uSi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     uSi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     uSi_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     uSi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned short' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     uSi_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     sSi_0 = b_1 ++;
    sSi_0 = uc_1 ++;
    sSi_0 = sc_1 ++;
    sSi_0 = uSi_1 ++;
    sSi_0 = sSi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned int' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = ui_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'int' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = si_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned long' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = uLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'short'; posible pérdida de datos
// (MSVC)     sSi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sSi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sSi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sSi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sSi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     sSi_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     sSi_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sSi_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     sSi_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     sSi_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     sSi_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sSi_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     sSi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     sSi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     sSi_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     sSi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'short' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     sSi_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     ui_0 = b_1 ++;
    ui_0 = uc_1 ++;
    ui_0 = sc_1 ++;
    ui_0 = uSi_1 ++;
    ui_0 = sSi_1 ++;
    ui_0 = ui_1 ++;
    ui_0 = si_1 ++;
    ui_0 = uLi_1 ++;
    ui_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'unsigned int'; posible pérdida de datos
// (MSVC)     ui_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'unsigned int'; posible pérdida de datos
// (MSVC)     ui_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'unsigned int'; posible pérdida de datos
// (MSVC)     ui_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'unsigned int'; posible pérdida de datos
// (MSVC)     ui_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'unsigned int'; posible pérdida de datos
// (MSVC)     ui_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     ui_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     ui_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     ui_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     ui_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     ui_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     ui_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     ui_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     ui_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     ui_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     ui_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     ui_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     ui_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     ui_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     ui_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     ui_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned int' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     ui_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     si_0 = b_1 ++;
    si_0 = uc_1 ++;
    si_0 = sc_1 ++;
    si_0 = uSi_1 ++;
    si_0 = sSi_1 ++;
    si_0 = ui_1 ++;
    si_0 = si_1 ++;
    si_0 = uLi_1 ++;
    si_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'int'; posible pérdida de datos
// (MSVC)     si_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'int'; posible pérdida de datos
// (MSVC)     si_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'int'; posible pérdida de datos
// (MSVC)     si_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'int'; posible pérdida de datos
// (MSVC)     si_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'int'; posible pérdida de datos
// (MSVC)     si_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     si_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     si_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     si_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     si_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     si_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     si_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     si_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     si_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     si_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     si_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     si_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     si_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     si_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     si_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     si_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'int' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     si_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     uLi_0 = b_1 ++;
    uLi_0 = uc_1 ++;
    uLi_0 = sc_1 ++;
    uLi_0 = uSi_1 ++;
    uLi_0 = sSi_1 ++;
    uLi_0 = ui_1 ++;
    uLi_0 = si_1 ++;
    uLi_0 = uLi_1 ++;
    uLi_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'unsigned long'; posible pérdida de datos
// (MSVC)     uLi_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'unsigned long'; posible pérdida de datos
// (MSVC)     uLi_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'unsigned long'; posible pérdida de datos
// (MSVC)     uLi_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'unsigned long'; posible pérdida de datos
// (MSVC)     uLi_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'unsigned long'; posible pérdida de datos
// (MSVC)     uLi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uLi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uLi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uLi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uLi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     uLi_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     uLi_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uLi_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     uLi_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     uLi_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     uLi_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uLi_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     uLi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     uLi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     uLi_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     uLi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned long' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     uLi_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     sLi_0 = b_1 ++;
    sLi_0 = uc_1 ++;
    sLi_0 = sc_1 ++;
    sLi_0 = uSi_1 ++;
    sLi_0 = sSi_1 ++;
    sLi_0 = ui_1 ++;
    sLi_0 = si_1 ++;
    sLi_0 = uLi_1 ++;
    sLi_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'long'; posible pérdida de datos
// (MSVC)     sLi_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'long'; posible pérdida de datos
// (MSVC)     sLi_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'long'; posible pérdida de datos
// (MSVC)     sLi_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'long'; posible pérdida de datos
// (MSVC)     sLi_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'long'; posible pérdida de datos
// (MSVC)     sLi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sLi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sLi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sLi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sLi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     sLi_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     sLi_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sLi_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     sLi_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     sLi_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     sLi_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sLi_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     sLi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     sLi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     sLi_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     sLi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'long' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     sLi_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     uLLi_0 = b_1 ++;
    uLLi_0 = uc_1 ++;
    uLLi_0 = sc_1 ++;
    uLLi_0 = uSi_1 ++;
    uLLi_0 = sSi_1 ++;
    uLLi_0 = ui_1 ++;
    uLLi_0 = si_1 ++;
    uLLi_0 = uLi_1 ++;
    uLLi_0 = sLi_1 ++;
    uLLi_0 = uLLi_1 ++;
    uLLi_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a 'unsigned __int64'; posible pérdida de datos
// (MSVC)     uLLi_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'unsigned __int64'; posible pérdida de datos
// (MSVC)     uLLi_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'unsigned __int64'; posible pérdida de datos
// (MSVC)     uLLi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uLLi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uLLi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uLLi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     uLLi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     uLLi_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     uLLi_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     uLLi_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     uLLi_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     uLLi_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     uLLi_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     uLLi_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     uLLi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     uLLi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     uLLi_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     uLLi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'unsigned __int64' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     uLLi_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     sLLi_0 = b_1 ++;
    sLLi_0 = uc_1 ++;
    sLLi_0 = sc_1 ++;
    sLLi_0 = uSi_1 ++;
    sLLi_0 = sSi_1 ++;
    sLLi_0 = ui_1 ++;
    sLLi_0 = si_1 ++;
    sLLi_0 = uLi_1 ++;
    sLLi_0 = sLi_1 ++;
    sLLi_0 = uLLi_1 ++;
    sLLi_0 = sLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'float' a '__int64'; posible pérdida de datos
// (MSVC)     sLLi_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a '__int64'; posible pérdida de datos
// (MSVC)     sLLi_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a '__int64'; posible pérdida de datos
// (MSVC)     sLLi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sLLi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sLLi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sLLi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     sLLi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     sLLi_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     sLLi_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     sLLi_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     sLLi_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     sLLi_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     sLLi_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     sLLi_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     sLLi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     sLLi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     sLLi_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     sLLi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': '__int64' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     sLLi_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     f_0 = b_1 ++;
    f_0 = uc_1 ++;
    f_0 = sc_1 ++;
    f_0 = uSi_1 ++;
    f_0 = sSi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned int' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = ui_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'int' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = si_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned long' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = uLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = sLLi_1 ++;
    f_0 = f_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'double' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'float'; posible pérdida de datos
// (MSVC)     f_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'float'
// (MSVC)     f_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'float'
// (MSVC)     f_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     f_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     f_0 = struct$si$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'char *' a 'float'
// (MSVC)     f_0 = pc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'short *' a 'float'
// (MSVC)     f_0 = pSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'float'
// (MSVC)     f_0 = pi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long *' a 'float'
// (MSVC)     f_0 = pLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de '__int64 *' a 'float'
// (MSVC)     f_0 = pLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float *' a 'float'
// (MSVC)     f_0 = pf_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'float'
// (MSVC)     f_0 = pd_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double *' a 'float'
// (MSVC)     f_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int (*)[0]' a 'float'
// (MSVC)     f_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double (*)[0]' a 'float'
// (MSVC)     f_0 = pad_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct1_t *' a 'float'
// (MSVC)     f_0 = pstruct$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct2_t *' a 'float'
// (MSVC)     f_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     d_0 = b_1 ++;
    d_0 = uc_1 ++;
    d_0 = sc_1 ++;
    d_0 = uSi_1 ++;
    d_0 = sSi_1 ++;
    d_0 = ui_1 ++;
    d_0 = si_1 ++;
    d_0 = uLi_1 ++;
    d_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'double'; posible pérdida de datos
// (MSVC)     d_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'double'; posible pérdida de datos
// (MSVC)     d_0 = sLLi_1 ++;
    d_0 = f_1 ++;
    d_0 = d_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'long double' a 'double'; posible pérdida de datos
// (MSVC)     d_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'double'
// (MSVC)     d_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'double'
// (MSVC)     d_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     d_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     d_0 = struct$si$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'char *' a 'double'
// (MSVC)     d_0 = pc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'short *' a 'double'
// (MSVC)     d_0 = pSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'double'
// (MSVC)     d_0 = pi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long *' a 'double'
// (MSVC)     d_0 = pLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de '__int64 *' a 'double'
// (MSVC)     d_0 = pLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float *' a 'double'
// (MSVC)     d_0 = pf_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'double'
// (MSVC)     d_0 = pd_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double *' a 'double'
// (MSVC)     d_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> fatal error C1003: el recuento de errores supera 100; se detiene la compilación
// (MSVC)     d_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double (*)[0]' a 'double'
// (MSVC)     d_0 = pad_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct1_t *' a 'double'
// (MSVC)     d_0 = pstruct$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct2_t *' a 'double'
// (MSVC)     d_0 = pstruct$si$si$si_1 ++;
// (GCC)>  error: increment of a boolean expression [-Werror=bool-operation]
// (GCC)     Ld_0 = b_1 ++;
    Ld_0 = uc_1 ++;
    Ld_0 = sc_1 ++;
    Ld_0 = uSi_1 ++;
    Ld_0 = sSi_1 ++;
    Ld_0 = ui_1 ++;
    Ld_0 = si_1 ++;
    Ld_0 = uLi_1 ++;
    Ld_0 = sLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de 'unsigned __int64' a 'long double'; posible pérdida de datos
// (MSVC)     Ld_0 = uLLi_1 ++;
// (MSVC)> warning C4244: '=': conversión de '__int64' a 'long double'; posible pérdida de datos
// (MSVC)     Ld_0 = sLLi_1 ++;
    Ld_0 = f_1 ++;
    Ld_0 = d_1 ++;
    Ld_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'long double'
// (MSVC)     Ld_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'long double'
// (MSVC)     Ld_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     Ld_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     Ld_0 = struct$si$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'char *' a 'long double'
// (MSVC)     Ld_0 = pc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'short *' a 'long double'
// (MSVC)     Ld_0 = pSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'long double'
// (MSVC)     Ld_0 = pi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long *' a 'long double'
// (MSVC)     Ld_0 = pLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de '__int64 *' a 'long double'
// (MSVC)     Ld_0 = pLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float *' a 'long double'
// (MSVC)     Ld_0 = pf_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'long double'
// (MSVC)     Ld_0 = pd_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double *' a 'long double'
// (MSVC)     Ld_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int (*)[0]' a 'long double'
// (MSVC)     Ld_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double (*)[0]' a 'long double'
// (MSVC)     Ld_0 = pad_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct1_t *' a 'long double'
// (MSVC)     Ld_0 = pstruct$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct2_t *' a 'long double'
// (MSVC)     Ld_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'int [3]'
// (MSVC)     ai_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'int [3]'
// (MSVC)     ai_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'int [3]'
// (MSVC)     ai_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     ai_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     ai_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pSi_1 ++;
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pi_1 ++;
// (MSVC)> warning C4057: '=': 'int [3]' tiene un direccionamiento indirecto distinto de 'long *' para tipos base parecidos
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'int [3]' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'int [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ai_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'double [3]'
// (MSVC)     ad_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'double [3]'
// (MSVC)     ad_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'double [3]'
// (MSVC)     ad_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     ad_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     ad_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pf_1 ++;
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pd_1 ++;
// (MSVC)> warning C4057: '=': 'double [3]' tiene un direccionamiento indirecto distinto de 'long double *' para tipos base parecidos
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'double [3]' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'double [3]'
// (MSVC)> error C2106: '=': el operando izquierdo debe ser valor L
// (MSVC)     ad_0 = pstruct$si$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'bool' a 'struct1_t'
// (MSVC)     struct$si$si_0 = b_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned char' a 'struct1_t'
// (MSVC)     struct$si$si_0 = uc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'char' a 'struct1_t'
// (MSVC)     struct$si$si_0 = sc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned short' a 'struct1_t'
// (MSVC)     struct$si$si_0 = uSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'short' a 'struct1_t'
// (MSVC)     struct$si$si_0 = sSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned int' a 'struct1_t'
// (MSVC)     struct$si$si_0 = ui_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int' a 'struct1_t'
// (MSVC)     struct$si$si_0 = si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned long' a 'struct1_t'
// (MSVC)     struct$si$si_0 = uLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long' a 'struct1_t'
// (MSVC)> fatal error C1003: el recuento de errores supera 100; se detiene la compilación
// (MSVC)     struct$si$si_0 = sLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned __int64' a 'struct1_t'
// (MSVC)     struct$si$si_0 = uLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de '__int64' a 'struct1_t'
// (MSVC)     struct$si$si_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'struct1_t'
// (MSVC)     struct$si$si_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'struct1_t'
// (MSVC)     struct$si$si_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'struct1_t'
// (MSVC)     struct$si$si_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     struct$si$si_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     struct$si$si_0 = struct$si$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'char *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'short *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de '__int64 *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pf_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pd_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int (*)[0]' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double (*)[0]' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pad_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct1_t *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pstruct$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct2_t *' a 'struct1_t'
// (MSVC)     struct$si$si_0 = pstruct$si$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'bool' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = b_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned char' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = uc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'char' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = sc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned short' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = uSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'short' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = sSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned int' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = ui_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned long' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = uLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = sLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'unsigned __int64' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = uLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de '__int64' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     struct$si$si$si_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     struct$si$si$si_0 = struct$si$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'char *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pc_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'short *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pSi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de '__int64 *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pf_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pd_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'int (*)[0]' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double (*)[0]' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pad_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct1_t *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pstruct$si$si_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'struct2_t *' a 'struct2_t'
// (MSVC)     struct$si$si$si_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pc_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pc_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pc_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pc_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pc_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pc_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pc_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pc_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pc_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pc_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pc_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'char *'
// (MSVC)     pc_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'char *'
// (MSVC)     pc_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'char *'
// (MSVC)     pc_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'char *'
// (MSVC)     pc_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'char *'
// (MSVC)     pc_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pc_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pc_0 = struct$si$si$si_1 ++;
    pc_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'char *'
// (MSVC)     pc_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'char *'
// (MSVC)     pc_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'char *'
// (MSVC)     pc_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'char *'
// (MSVC)     pc_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'char *'
// (MSVC)     pc_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'char *'
// (MSVC)     pc_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'char *'
// (MSVC)     pc_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pc_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'char *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pc_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'char *'
// (MSVC)     pc_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'char *'
// (MSVC)     pc_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pSi_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pSi_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pSi_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pSi_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pSi_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pSi_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pSi_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pSi_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pSi_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pSi_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pSi_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'short *'
// (MSVC)     pSi_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'short *'
// (MSVC)     pSi_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'short *'
// (MSVC)     pSi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'short *'
// (MSVC)     pSi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'short *'
// (MSVC)     pSi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pSi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pSi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'short *'
// (MSVC)     pSi_0 = pc_1 ++;
    pSi_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'short *'
// (MSVC)     pSi_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'short *'
// (MSVC)     pSi_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'short *'
// (MSVC)     pSi_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'short *'
// (MSVC)     pSi_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'short *'
// (MSVC)     pSi_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'short *'
// (MSVC)     pSi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pSi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'short *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pSi_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'short *'
// (MSVC)     pSi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'short *'
// (MSVC)     pSi_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pi_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pi_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pi_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pi_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pi_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pi_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pi_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pi_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pi_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pi_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pi_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'int *'
// (MSVC)     pi_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'int *'
// (MSVC)     pi_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'int *'
// (MSVC)     pi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)     pi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'int *'
// (MSVC)     pi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'int *'
// (MSVC)     pi_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'int *'
// (MSVC)     pi_0 = pSi_1 ++;
    pi_0 = pi_1 ++;
// (MSVC)> warning C4057: '=': 'int *' tiene un direccionamiento indirecto distinto de 'long *' para tipos base parecidos
// (MSVC)     pi_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'int *'
// (MSVC)     pi_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'int *'
// (MSVC)     pi_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'int *'
// (MSVC)     pi_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'int *'
// (MSVC)     pi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'int *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pi_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'int *'
// (MSVC)     pi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'int *'
// (MSVC)     pi_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pLi_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pLi_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pLi_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pLi_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pLi_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pLi_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pLi_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pLi_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pLi_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pLi_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pLi_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'long *'
// (MSVC)     pLi_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'long *'
// (MSVC)     pLi_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'long *'
// (MSVC)     pLi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4057: '=': 'long *' tiene un direccionamiento indirecto distinto de 'int *' para tipos base parecidos
// (MSVC)     pLi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'long *'
// (MSVC)     pLi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pLi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pLi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'long *'
// (MSVC)     pLi_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'long *'
// (MSVC)     pLi_0 = pSi_1 ++;
// (MSVC)> warning C4057: '=': 'long *' tiene un direccionamiento indirecto distinto de 'int *' para tipos base parecidos
// (MSVC)     pLi_0 = pi_1 ++;
    pLi_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'long *'
// (MSVC)     pLi_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'long *'
// (MSVC)     pLi_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'long *'
// (MSVC)     pLi_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'long *'
// (MSVC)     pLi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pLi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'long *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pLi_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'long *'
// (MSVC)     pLi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'long *'
// (MSVC)     pLi_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pLLi_0 = b_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pLLi_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pLLi_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pLLi_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pLLi_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pLLi_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pLLi_0 = si_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pLLi_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pLLi_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pLLi_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pLLi_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a '__int64 *'
// (MSVC)     pLLi_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a '__int64 *'
// (MSVC)     pLLi_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a '__int64 *'
// (MSVC)     pLLi_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a '__int64 *'
// (MSVC)     pLLi_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a '__int64 *'
// (MSVC)     pLLi_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)> fatal error C1003: el recuento de errores supera 100; se detiene la compilación
// (MSVC)     pLLi_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pLLi_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a '__int64 *'
// (MSVC)     pLLi_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a '__int64 *'
// (MSVC)     pLLi_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a '__int64 *'
// (MSVC)     pLLi_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a '__int64 *'
// (MSVC)     pLLi_0 = pLi_1 ++;
    pLLi_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a '__int64 *'
// (MSVC)     pLLi_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a '__int64 *'
// (MSVC)     pLLi_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a '__int64 *'
// (MSVC)     pLLi_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pLLi_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': '__int64 *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pLLi_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a '__int64 *'
// (MSVC)     pLLi_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a '__int64 *'
// (MSVC)     pLLi_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pf_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pf_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pf_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pf_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pf_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pf_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pf_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pf_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pf_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pf_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pf_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'float *'
// (MSVC)     pf_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'float *'
// (MSVC)     pf_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'float *'
// (MSVC)     pf_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'float *'
// (MSVC)     pf_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'float *'
// (MSVC)     pf_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pf_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pf_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'float *'
// (MSVC)     pf_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'float *'
// (MSVC)     pf_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'float *'
// (MSVC)     pf_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'float *'
// (MSVC)     pf_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'float *'
// (MSVC)     pf_0 = pLLi_1 ++;
    pf_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'float *'
// (MSVC)     pf_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'float *'
// (MSVC)     pf_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pf_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'float *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pf_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'float *'
// (MSVC)     pf_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'float *'
// (MSVC)     pf_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pd_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pd_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pd_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pd_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pd_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pd_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pd_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pd_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pd_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pd_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pd_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'double *'
// (MSVC)     pd_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'double *'
// (MSVC)     pd_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'double *'
// (MSVC)     pd_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'double *'
// (MSVC)     pd_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)     pd_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pd_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pd_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'double *'
// (MSVC)     pd_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'double *'
// (MSVC)     pd_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'double *'
// (MSVC)     pd_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'double *'
// (MSVC)     pd_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'double *'
// (MSVC)     pd_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'double *'
// (MSVC)     pd_0 = pf_1 ++;
    pd_0 = pd_1 ++;
// (MSVC)> warning C4057: '=': 'double *' tiene un direccionamiento indirecto distinto de 'long double *' para tipos base parecidos
// (MSVC)     pd_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pd_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'double *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pd_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'double *'
// (MSVC)     pd_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'double *'
// (MSVC)     pd_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pLd_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pLd_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pLd_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pLd_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pLd_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pLd_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pLd_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pLd_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pLd_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pLd_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pLd_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'long double *'
// (MSVC)     pLd_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'long double *'
// (MSVC)     pLd_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'long double *'
// (MSVC)     pLd_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'long double *'
// (MSVC)     pLd_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4057: '=': 'long double *' tiene un direccionamiento indirecto distinto de 'double *' para tipos base parecidos
// (MSVC)     pLd_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pLd_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pLd_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'long double *'
// (MSVC)     pLd_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'long double *'
// (MSVC)     pLd_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'long double *'
// (MSVC)     pLd_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'long double *'
// (MSVC)     pLd_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'long double *'
// (MSVC)     pLd_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'long double *'
// (MSVC)     pLd_0 = pf_1 ++;
// (MSVC)> warning C4057: '=': 'long double *' tiene un direccionamiento indirecto distinto de 'double *' para tipos base parecidos
// (MSVC)     pLd_0 = pd_1 ++;
    pLd_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pLd_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'long double *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pLd_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'long double *'
// (MSVC)     pLd_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'long double *'
// (MSVC)     pLd_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pai_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pai_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pai_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pai_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pai_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pai_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pai_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pai_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pai_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pai_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pai_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'int (*)[0]'
// (MSVC)     pai_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'int (*)[0]'
// (MSVC)     pai_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'int (*)[0]'
// (MSVC)     pai_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     pai_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     pai_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pai_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pai_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     pai_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     pai_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     pai_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     pai_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     pai_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     pai_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     pai_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     pai_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)     pai_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double (*)[0]' a 'int (*)[0]'
// (MSVC)     pai_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     pai_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'int (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     pai_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pad_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pad_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pad_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pad_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pad_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pad_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pad_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pad_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pad_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pad_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pad_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'double (*)[0]'
// (MSVC)     pad_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'double (*)[0]'
// (MSVC)     pad_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'double (*)[0]'
// (MSVC)     pad_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     pad_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     pad_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pad_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pad_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'char *'
// (MSVC)     pad_0 = pc_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'short *'
// (MSVC)     pad_0 = pSi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'int *'
// (MSVC)     pad_0 = pi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'long *'
// (MSVC)     pad_0 = pLi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de '__int64 *'
// (MSVC)     pad_0 = pLLi_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'float *'
// (MSVC)     pad_0 = pf_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'double *'
// (MSVC)     pad_0 = pd_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'long double *'
// (MSVC)     pad_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int (*)[0]' a 'double (*)[0]'
// (MSVC)     pad_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)     pad_0 = pad_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'struct1_t *'
// (MSVC)     pad_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'double (*)[0]' es distinto en los niveles de direccionamiento indirecto de 'struct2_t *'
// (MSVC)     pad_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pstruct$si$si_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pstruct$si$si_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pstruct$si$si_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pstruct$si$si_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pstruct$si$si_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pstruct$si$si_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pstruct$si$si_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pstruct$si$si_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pstruct$si$si_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pstruct$si$si_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pstruct$si$si_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pstruct$si$si_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pstruct$si$si_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pstruct$si$si_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'struct1_t *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pstruct$si$si_0 = pad_1 ++;
    pstruct$si$si_0 = pstruct$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct2_t *' a 'struct1_t *'
// (MSVC)     pstruct$si$si_0 = pstruct$si$si$si_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'bool'
// (MSVC)     pstruct$si$si$si_0 = b_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned char'
// (MSVC)     pstruct$si$si$si_0 = uc_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'char'
// (MSVC)     pstruct$si$si$si_0 = sc_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned short'
// (MSVC)     pstruct$si$si$si_0 = uSi_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'short'
// (MSVC)     pstruct$si$si$si_0 = sSi_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned int'
// (MSVC)     pstruct$si$si$si_0 = ui_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'int'
// (MSVC)     pstruct$si$si$si_0 = si_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned long'
// (MSVC)     pstruct$si$si$si_0 = uLi_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'long'
// (MSVC)     pstruct$si$si$si_0 = sLi_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'unsigned __int64'
// (MSVC)     pstruct$si$si$si_0 = uLLi_1 ++;
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de '__int64'
// (MSVC)     pstruct$si$si$si_0 = sLLi_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'float' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = f_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'double' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = d_1 ++;
// (MSVC)> error C2440: '=': no se puede realizar la conversión de 'long double' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = Ld_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = ai_1 ++;
// (MSVC)> error C2105: '++' necesita valor L
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = ad_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pstruct$si$si$si_0 = struct$si$si_1 ++;
// (MSVC)> error C2088: '++': no es válido para struct
// (MSVC)     pstruct$si$si$si_0 = struct$si$si$si_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'char *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pc_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'short *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pSi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'int *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de '__int64 *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pLLi_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'float *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pf_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'double *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pd_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'long double *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pLd_1 ++;
// (MSVC)> error C2036: 'int (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'int (*)[0]'
// (MSVC)     pstruct$si$si$si_0 = pai_1 ++;
// (MSVC)> error C2036: 'double (*)[0]': tamaño desconocido
// (MSVC)> warning C4047: '=': 'struct2_t *' es distinto en los niveles de direccionamiento indirecto de 'double (*)[0]'
// (MSVC)     pstruct$si$si$si_0 = pad_1 ++;
// (MSVC)> warning C4133: '=': tipos incompatibles, de 'struct1_t *' a 'struct2_t *'
// (MSVC)     pstruct$si$si$si_0 = pstruct$si$si_1 ++;
    pstruct$si$si$si_0 = pstruct$si$si$si_1 ++;

    return 0;
}
